Download MT2018001_MT2018093_MT2018111.zip

Drive link(for pickle):https://drive.google.com/drive/folders/1AEpW8dcN1NC3ilVipFqHhASsKETFFHmj

folders:1).code-->contains jupyter file,python file,pickle file,train.csv,test.csv
		2).latex report-->Latex source code,Report in pdf	
We have used XGBoost as the final model in the project. 
Validation : Uncomment the function with name "validateXGBoost", in this fuction we have divided the function into the ratio of 80:20 for the training and validtion respectively.  "testXGBoost" and comment the function "validateXGBoost"

Steps to run the code
Visualization : 
1) Uncomment the visualization block which contain the function "numCategory", "numPdDistrict" etc;
2) Comment the line from 218 to 228 and 240 to 256 and uncomment the line from 231 to 237 as per requirement 

Test :
1) Comment line number 218 to 254 and uncomment line 255 and 256
2) truth.csv is required to check the logloss

Validation :
1) Comment line 250 and 252 to 256

Libraries used : XGBoost, numpy, pandas, matplotlib, seaborn.

Pickle File Format : 
input have files have the format .pkl
models have file the format .sav

REMARK
1) For validation we had used XGBv.sav (pickle version 0.20.1)
2) In Kaggel Competition we use whole for training hence to predict kaggel test data use XGB.sav (version 0.20.0) instead of XGBv.sav in the "testXGB" function 