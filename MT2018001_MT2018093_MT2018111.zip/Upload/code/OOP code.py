#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().run_line_magic('matplotlib', 'inline')

import warnings
warnings.filterwarnings('ignore')
warnings.filterwarnings('ignore', category=DeprecationWarning)

import pandas as pd
pd.options.display.max_columns = 100

from matplotlib import pyplot as plt
import numpy as np

import seaborn as sns
sns.set(rc={'figure.figsize':(12,9)})
import pylab as plot
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss,accuracy_score
from xgboost import XGBClassifier
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import pickle


# In[2]:


#pd.to_pickle(pd.read_csv('train.csv'), "./train.pkl")
#pd.to_pickle(pd.read_csv('test.csv'), "./test.pkl")
data = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')


# In[3]:


class FeatureEngineering(object):
    
    def datatimeSplit(self,dataframe):
        self.datetime=dataframe.Dates.str.split(pat=" ",expand=True)
        self.datetime.columns=['Date','Time']
        self.Date=self.datetime.Date.str.split(pat="-",expand=True)
        self.Date.columns=['Year','Month','Day']
        self.Time=self.datetime.Time.str.split(pat=":",expand=True)
        self.Time.columns=['Hour','Minute','Second']
        dataframe=dataframe.drop(labels=['Dates'],axis=1)
        dataframe=pd.concat([dataframe,self.Date,self.Time],axis=1)
        
        return dataframe
    
    def clubAll(self,dataframe):
        self.minuteClubbing(dataframe)
        self.dowClubbing(dataframe)
        self.clustering(dataframe)
        self.rotatingDegree(dataframe)
        dataframe=self.extractingAddress(dataframe)
        return dataframe
    
    def rotatingDegree(self,dataframe):
       
        dataframe["rot30_X"]=(1.732/2) * dataframe["Y"] + 0.5 * dataframe["X"]
        dataframe["rot30_Y"]=(1.732/2) * dataframe["Y"] - 0.5 * dataframe["X"]   
        dataframe["rot45_X"]=0.707 * dataframe["Y"] + 0.707 * dataframe["X"]
        dataframe["rot45_Y"]=0.707 * dataframe["Y"] - 0.707 * dataframe["X"]
        dataframe["rot60_X"]=(0.5) * dataframe["Y"] + (1.732/2) * dataframe["X"]
        dataframe["rot60_Y"]=0.5 * dataframe["Y"] - (1.732/2) * dataframe["X"]
        dataframe["raw_radial"]=np.sqrt(np.power(dataframe['X'],2) + np.power(dataframe['Y'],2))
        dataframe["radial60"]=np.sqrt(np.power(dataframe['rot60_X'],2) + np.power(dataframe['rot60_Y'],2))
        #return dataframe
    
    def minuteClubbing(self,dataframe):
        dataframe['Minute']=dataframe['Minute'].apply(lambda x:int(x))
        dataframe['Minute']=dataframe['Minute'].apply(lambda x : 'low' if x <31 else 'high')
    
    def dowClubbing(self,dataframe):
        dataframe['DayOfWeek']= dataframe['DayOfWeek'].apply(lambda x : 'WeekHigh' if x in ('Wednesday','Friday') else ('WeekMed' if x in ('Tuesday','Thursday','Saturday') else 'WeekLow'))

    def extractingAddress(self,dataframe):
        dataframe['Intersection']=dataframe['Address'].apply(lambda x : 1 if '/' in x else 0)
        dataframe['Block']=dataframe['Address'].apply(lambda x : 1 if 'Block' in x else 0)
        self.address=pd.DataFrame(dataframe['Address'],columns=['Address'])
        self.address=self.address.Address.str.split(pat=" /",expand=True )

        self.address.columns=['Address','Intr2']

        self.address=self.address.Address.str.split(pat=" /",expand=True )
        self.address.columns=['Address']

        self.string=self.address.iloc[:,0]
        self.string=self.string.str.strip()

        self.address_fram=self.string.to_frame()
        self.temp=self.address_fram['Address'].astype(str).str[-2:]

        self.address=self.temp.to_frame()
        
        self.address['Address']=self.address['Address'].apply(lambda x :( x if x in ("ST","AV","LN","DR","BL","HY","CT","RD","PL","PZ","TR","AL","CR","WK","EX","RW") else (("I-80" if x in ("80") else ("HWY" if x in ("WY") else ("WAY" if x in ("AY") else ("TER" if x in ("ER") else ("ALMS" if x in ("MS") else ("MAR" if x in ("AR") else ("PARK" if x in ("RK") else ("STWY" if x in ("WY") else ("VIA" if x in ("NO") else ("BLOCK")))))))))))))
        dataframe=dataframe.drop(labels=['Address'],axis=1)
        
        dataframe=pd.concat([self.address,dataframe],axis=1)
        #print(dataframe)
        return dataframe
        
    def clustering(self,dataframe):
        xy_scaler = StandardScaler()
        xy_scaler.fit(dataframe.loc[:,['X','Y']])
        xy_scaled = xy_scaler.transform(dataframe.loc[:,['X','Y']])
        kmeans = KMeans(n_clusters=26, init='k-means++')
        kmeans.fit(xy_scaled);

        geoData = dataframe.loc[:,['X','Y']]
        dataframe['closest_centers_f'] = kmeans.predict(geoData)
        id_label=kmeans.labels_
        dataframe.loc[:,'label'] = pd.Series(kmeans.labels_)


# In[4]:


le = preprocessing.LabelEncoder()

class Preprocessing(object):
    
    def callLabelEncoder(self,column_list,data):
        
        for val in column_list:
            data=self.labelEncoding(col=val,dataframe=data)
        
        return data

    def labelEncoding(self,col,dataframe):
        le_res=le.fit_transform(dataframe[col])
        column=pd.DataFrame(le_res)
        column.columns=[col]
        dataframe=dataframe.drop(labels=[col],axis=1)
        dataframe=pd.concat([column,dataframe],axis=1)
        
        return dataframe
    
    def columnDropping(self,columns,dataframe):
        dataframe=dataframe.drop(labels=columns,axis=1)
        return dataframe


# In[5]:


class Model(object):
    def __init__(self,train,test):
            global Id,y,Id_test
            y=pd.DataFrame(train['Category'])
            Id=train['Id']
            Id_test=test['Id']
            
            cols=['Descript','Resolution','Category','Id', 'Second','rot60_X', 'rot60_Y']
            prep=Preprocessing()
            self.train= prep.columnDropping(cols,train)
            cols=['Descript','Resolution','Id', 'Second','rot60_X', 'rot60_Y']
            self.test= prep.columnDropping(cols,test)
            
            self.X_train,self.X_test,self.y_train,self.y_test=train_test_split(self.train,y,test_size=0.20,shuffle=False)
            self.model = xgb.XGBClassifier(learning_rate=0.02,n_estimators=800,max_depth=6,subsample=0.8,colsample_bytree=0.8,max_delta_step=1,objective='multi:softmax',nthread=4,seed=1747)
    
    def trainXGBoost(self):
            self.model.fit(self.X_train,self.y_train)
            self.filename = 'XGBv.sav'
            pickle.dump(self.model, open(self.filename, 'wb'))
            
    def validateXGBoost(self):
            self.filename = 'XGBv.sav'
            self.loaded_model = pickle.load(open(self.filename, 'rb'))
            self.y_pred=self.loaded_model.predict_proba(self.X_test)
            print (log_loss(self.y_test,self.y_pred));
    
    def testXGBoost(self,truth):
            self.filename = 'XGBv.sav'
            self.loaded_model = pickle.load(open(self.filename, 'rb'))
            self.y_pred=self.loaded_model.predict_proba(self.test)
            print (log_loss(self.truth,self.y_pred));      


# In[6]:


class Visualization(object):
    def numCategory(self,dataframe):
        dataframe.Category.value_counts()[:36].plot(kind='bar',figsize=(10,10))
        plt.legend()
    def numPdDistrict(self,dataframe):   
        dataframe.PdDistrict.value_counts().plot(kind='bar',label='Crimes by PdDistrict',figsize=(5,3))
        plt.legend()
    def numYear(self,dataframe):   
        dataframe.Year.value_counts().plot(kind='bar',label='Crimes by Year',figsize=(5,3))
        plt.legend() 
    def numMonth(self,dataframe):    
        dataframe.Month.value_counts().sort_index().plot(kind='Bar',label='Crimes by Month',figsize=(7,5))
        plt.legend(bbox_to_anchor=(1,1.2))
    def numHour(self,dataframe):
        dataframe.Hour.value_counts().sort_index().plot(kind='bar',label='Crimes by Hour (Of Day)')
        plt.legend(bbox_to_anchor=(1,1.2))
    def numdayOfWeek(self,dataframe):
        dataframe.DayOfWeek.value_counts().sort_index().plot(kind='bar',label='Crimes by Day)')
        plt.legend(bbox_to_anchor=(1,1.2))


# In[7]:


if __name__ == "__main__":
    
    df=data
    df_test=test
#=================feature engineering=================================

    fe=FeatureEngineering()
    
    df=fe.datatimeSplit(df)
    df_test=fe.datatimeSplit(df_test)
    
    df=fe.clubAll(df)
    df_test=fe.clubAll(df_test)
#===================Visualization======================================   
    
    vi=Visualization()
    #vi.numCategory(df)
    #vi.numPdDistrict(df)
    #vi.numYear(df)
    #vi.numMonth(df)
    #vi.numHour(df)
    #vi.numdayOfWeek(df)
#===================Preprocessing========================================

    pre=Preprocessing()
    column_train=['DayOfWeek','Category','PdDistrict','Year','Month','Day','Address','Minute','Hour']
    df=pre.callLabelEncoder(column_train,df)
    #column_test=['DayOfWeek','PdDistrict','Year','Month','Day','Address','Minute','Hour']
    #df_test=pre.callLabelEncoder(column_test,df_test)
    
#===================Model training=======================================    
    #splitting into train and test
    model=Model(df,df_test)
    
    #model.trainXGBoost()
    model.validateXGBoost()
    
#===================Prediction on Kaggle test Set=====================================

    #truth=pd.read_csv('truth.csv')
    #model.testXGBoost(truth)


# In[ ]:




